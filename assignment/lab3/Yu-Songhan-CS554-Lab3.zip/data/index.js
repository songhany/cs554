const showData = require('./shows');

module.exports = {
  shows: showData,
}