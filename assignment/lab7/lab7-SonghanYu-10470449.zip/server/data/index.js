const pokemonData = require('./pokemons');

module.exports = {
  pokemons: pokemonData,
};